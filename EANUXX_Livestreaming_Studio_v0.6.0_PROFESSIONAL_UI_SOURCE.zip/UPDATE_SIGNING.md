# EANUXX Update Signing

This release is an update build and must use the existing EANUXX signing certificate.

- Package: `com.wEANUXX_20148007`
- Version code: `9`
- Version name: `0.6.0-professional-ui`
- Keep the existing keystore/alias configured in GitHub Actions.
- Do not generate a replacement certificate for this release.
- The workflow verifies the certificate fingerprint before signing and verifies the final APK afterward.

A normal Android update preserves the app's private data and Android Keystore-backed keys when package identity and signing identity remain compatible.
