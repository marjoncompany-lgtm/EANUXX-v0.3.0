# EANUXX Livestreaming Studio — v0.6.0 Professional UI

Created by Marjon Sealza.

## Update safety
- Application ID remains `com.wEANUXX_20148007`.
- Version code is `9`, higher than the previous v0.5.2 build.
- Future releases must be signed with the same EANUXX signing certificate.
- Android app data and the existing Android Keystore key are preserved during a normal update.
- Never generate a new signing certificate for an update.

## Professional UI update
- Extravagant dark studio visual system with neon cyan, electric blue, purple and pink accents.
- Premium EANUXX brand treatment and production-status header.
- Home dashboard redesigned around a Quick Launch hero, production tools, destination control and live metrics.
- Studio redesigned as a compact mobile production control room with camera preview framing, stream-health metrics, destination states and quick controls.
- Glass-style cards, refined borders, stronger typography hierarchy, larger touch targets and more deliberate spacing.
- Existing five-platform connection/Auto-Fill architecture is retained.
- Real CameraX preview and front/back camera switching are retained.

## Capability note
This project is a professional Android control/UI foundation. Camera preview, local chat, scenes, audio controls, settings, secure storage and entertainment WebView are implemented. Actual broadcast transport still requires the appropriate media engine and each platform's current authorized live API or ingest endpoint. Platform-specific limitations must be verified before release.
