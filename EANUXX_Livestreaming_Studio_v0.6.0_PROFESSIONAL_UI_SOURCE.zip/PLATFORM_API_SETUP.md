# Platform API setup required for real automatic credentials

The Android project is intentionally free of hard-coded client secrets. Before enabling real platform OAuth/API retrieval, create and configure the official developer applications for the destinations you intend to support.

## YouTube
- Create a Google/YouTube API project and OAuth client for the Android application.
- Enable the YouTube Data/Live Streaming API as required.
- Request only the scopes needed to create/manage the user's live broadcasts and streams.
- Use the Live Streaming API to create the broadcast/stream and obtain the ingestion configuration.

## Facebook / Instagram
- Create a Meta developer application.
- Configure the appropriate Login/OAuth products and redirect URIs.
- Request only the permissions required for the intended Page/Instagram professional account live workflow.
- Complete Meta review/eligibility requirements where applicable.
- Keep any app secret on a backend; never ship it in the APK.

## TikTok
- Create a TikTok for Developers application.
- Configure Login Kit/OAuth.
- Request only approved scopes/products required for the intended Live workflow.
- Complete TikTok's app review/approval requirements before relying on Live APIs.

## X
- Create an X developer application if you need account authorization for supported X APIs.
- The current project keeps RTMP Server URL / Stream Key manual because a current official X Live ingest API was not confirmed.

## Backend

For providers whose token exchange requires a client secret, deploy a small HTTPS backend. Recommended endpoints:

- `GET /oauth/{platform}/start`
- `GET /oauth/{platform}/callback`
- `POST /api/{platform}/live-credentials`
- `POST /api/{platform}/disconnect`

The backend should validate OAuth state/PKCE, exchange authorization codes, call the official platform API, return only the minimum live configuration needed by the Android client, and never log stream keys or access tokens.
