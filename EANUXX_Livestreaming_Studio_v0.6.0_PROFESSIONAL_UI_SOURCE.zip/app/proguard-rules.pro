# Keep Compose and reflection used by navigation
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**
