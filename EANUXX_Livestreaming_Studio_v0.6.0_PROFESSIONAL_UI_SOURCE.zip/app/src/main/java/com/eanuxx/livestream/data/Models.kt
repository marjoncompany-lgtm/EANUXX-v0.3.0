package com.eanuxx.livestream.data

data class PlatformAccount(
    val id: String,
    val name: String,
    val displayName: String,
    val isConnected: Boolean = false,
    val viewerCount: Int = 0,
    val color: Long
)

data class SceneItem(
    val id: String,
    val name: String,
    val type: String,
    val isActive: Boolean = false
)

data class AudioSource(
    val id: String,
    val name: String,
    val level: Float = 0.7f,
    val isMuted: Boolean = false
)

data class ConnectedDevice(
    val id: String,
    val name: String,
    val type: String,
    val isConnected: Boolean = true
)

object MockData {
    val platforms = listOf(
        PlatformAccount("yt", "YouTube", "YouTube", false, 0, 0xFFFF0000),
        PlatformAccount("fb", "Facebook", "Facebook", false, 0, 0xFF1877F2),
        PlatformAccount("ig", "Instagram", "Instagram", false, 0, 0xFFE4405F),
        PlatformAccount("tt", "TikTok", "TikTok", false, 0, 0xFF000000),
        PlatformAccount("x", "X", "X (Twitter)", false, 0, 0xFF1DA1F2)
    )

    val scenes = listOf(
        SceneItem("1", "Live Camera", "camera", true),
        SceneItem("2", "Karaoke", "karaoke"),
        SceneItem("3", "YouTube Video", "youtube"),
        SceneItem("4", "Screen Share", "screen"),
        SceneItem("5", "Interview", "interview"),
        SceneItem("6", "BRB", "brb"),
        SceneItem("7", "Ending", "ending")
    )

    val audioSources = listOf(
        AudioSource("mic", "Microphone", 0.80f),
        AudioSource("cam", "Camera Audio", 0.60f),
        AudioSource("yt", "YouTube / Browser", 0.70f),
        AudioSource("bgm", "Music / BGM", 0.45f),
        AudioSource("bt", "Bluetooth Device", 0.65f)
    )

    val devices = listOf(
        ConnectedDevice("1", "Webcam (Logitech BRIO)", "camera"),
        ConnectedDevice("2", "Microphone (HyperX)", "mic"),
        ConnectedDevice("3", "Bluetooth Speaker", "speaker"),
        ConnectedDevice("4", "Studio Lights", "light")
    )

    val totalViewers: Int get() = platforms.sumOf { it.viewerCount }
}
