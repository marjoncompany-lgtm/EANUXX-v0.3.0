package com.eanuxx.livestream.data

import android.content.Context

/** Persistent non-secret app preferences. Secrets remain in SecureStore. */
class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("eanuxx_app", Context.MODE_PRIVATE)

    var setupCompleted: Boolean
        get() = prefs.getBoolean("setup_completed", false)
        set(value) { prefs.edit().putBoolean("setup_completed", value).apply() }

    var lastSeenVersionCode: Int
        get() = prefs.getInt("last_seen_version_code", 0)
        set(value) { prefs.edit().putInt("last_seen_version_code", value).apply() }

    var autoReconnect: Boolean
        get() = prefs.getBoolean("auto_reconnect", true)
        set(value) { prefs.edit().putBoolean("auto_reconnect", value).apply() }

    var lowLatency: Boolean
        get() = prefs.getBoolean("low_latency", true)
        set(value) { prefs.edit().putBoolean("low_latency", value).apply() }
}
