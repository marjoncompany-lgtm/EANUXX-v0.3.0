package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.data.MockData
import com.eanuxx.livestream.ui.components.*
import com.eanuxx.livestream.ui.theme.*

@Composable
fun HomeScreen(onNavigate: (String) -> Unit, onStartAll: () -> Unit) {
    NeonBackdrop(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 15.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EanuxxBrand(compact = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(Success))
                    Spacer(Modifier.width(6.dp))
                    Text("READY", color = Success, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    IconButton(onClick = { onNavigate("settings") }) {
                        Icon(Icons.Default.Tune, "Settings", tint = TextSecondary)
                    }
                }
            }

            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(4.dp))
                Text("YOUR STAGE", color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Go live without limits.", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 32.sp)
                Text("Everything you need to produce a professional broadcast from one control room.", color = TextSecondary, fontSize = 13.sp, lineHeight = 19.sp)

                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.fillMaxWidth().height(176.dp).clip(RoundedCornerShape(26.dp)).shadow(16.dp, RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF182A62), Color(0xFF37215E), Color(0xFF172036))))
                        .border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(26.dp)).padding(20.dp)
                ) {
                    Column(Modifier.align(Alignment.CenterStart)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.RocketLaunch, null, tint = Color.White, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("QUICK LAUNCH", color = Color.White.copy(.75f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Start your production", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Auto-prepare connected destinations", color = Color.White.copy(.72f), fontSize = 12.sp)
                        Spacer(Modifier.height(15.dp))
                        Button(
                            onClick = onStartAll,
                            modifier = Modifier.height(42.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentCyan)
                        ) {
                            Text("START ALL", color = Color(0xFF00131A), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                        }
                    }
                    Box(Modifier.align(Alignment.TopEnd).size(110.dp).clip(CircleShape).background(Brush.radialGradient(listOf(AccentCyan.copy(.28f), Color.Transparent))))
                    Icon(Icons.Default.WifiTethering, null, tint = Color.White.copy(.16f), modifier = Modifier.align(Alignment.BottomEnd).size(86.dp))
                }

                Spacer(Modifier.height(22.dp))
                SectionHeader("Production Tools", "Studio") { onNavigate("studio") }
                Spacer(Modifier.height(10.dp))
                val tiles = listOf(
                    Triple(Icons.Default.Videocam, "Camera", "studio"),
                    Triple(Icons.Default.ScreenShare, "Screen", "entertainment"),
                    Triple(Icons.Default.LiveTv, "Sources", "entertainment"),
                    Triple(Icons.Default.Stream, "Multistream", "studio"),
                    Triple(Icons.Default.Chat, "Live Chat", "live_chat"),
                    Triple(Icons.Default.Analytics, "Analytics", "analytics")
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    modifier = Modifier.height(214.dp),
                    userScrollEnabled = false
                ) {
                    items(tiles) { (icon, label, route) -> QuickActionTile(icon, label, { onNavigate(route) }, if (label == "Multistream") AccentPink else Primary) }
                }

                Spacer(Modifier.height(20.dp))
                SectionHeader("Destinations", "Manage") { onNavigate("settings") }
                Spacer(Modifier.height(10.dp))
                StudioCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("5 PLATFORMS", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Connect once. Control every destination.", color = TextMuted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.Hub, null, tint = AccentPurple, modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    MockData.platforms.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                            row.forEach { p -> PlatformChip(p.displayName, p.isConnected, Color(p.color)) }
                        }
                        Spacer(Modifier.height(7.dp))
                    }                }

                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    MetricCard("VIEWERS", "0", "Waiting", Icons.Default.Visibility, Modifier.weight(1f))
                    MetricCard("SCENES", "7", "Ready", Icons.Default.Layers, Modifier.weight(1f))
                    MetricCard("STATUS", "READY", "All systems", Icons.Default.Verified, Modifier.weight(1f))
                }
                Spacer(Modifier.height(24.dp))
            }
            BottomNavBar("home", onNavigate)
        }
    }
}

