package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.data.MockData
import com.eanuxx.livestream.ui.components.BottomNavBar
import com.eanuxx.livestream.ui.theme.*

// ─── Live Chat ───────────────────────────────────────────────────────────────
@Composable
fun LiveChatScreen(onNavigate: (String) -> Unit) {
    val messages = listOf(
        "jennycute" to "Can you sing My Heart Will Go On? ❤️",
        "kuyajerome" to "Ganda ng boses!",
        "maria_12" to "Request naman ng Through the Years 🎵",
        "kiktoluser" to "More karaoke songs please! 🔥",
        "userx_2026" to "Solid stream! Keep going!",
        "gamefan" to "Bro do some gaming next! 🎮",
        "musiclover" to "Amazing voice! ❤️",
        "pinoyviewer" to "Pa shoutout po from Bataan!"
    )
    var input by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    val sentMessages = remember { mutableStateListOf<Pair<String, String>>() }

    Column(Modifier.fillMaxSize().statusBarsPadding().background(Background)) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onNavigate("studio") }) {
                Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
            }
            Text("Live Chat (All Platforms)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.Settings, null, tint = TextMuted)
        }

        // Platform filter chips
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "YouTube", "Facebook", "TikTok").forEach { label ->
                FilterChip(
                    selected = selectedFilter == label,
                    onClick = { selectedFilter = label },
                    label = { Text(if (label == "All") "All (5.9K)" else label, fontSize = 12.sp) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages + sentMessages) { (user, msg) ->
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        Modifier.size(32.dp).clip(CircleShape).background(SurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(user.take(1).uppercase(), color = TextPrimary, fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(user, color = Primary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(msg, color = TextPrimary, fontSize = 14.sp)
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Type a message…") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Primary,
                    unfocusedBorderColor = CardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = {
                    val trimmed = input.trim()
                    if (trimmed.isNotEmpty()) {
                        sentMessages.add("You" to trimmed)
                        input = ""
                    }
                },
                modifier = Modifier.clip(CircleShape).background(Primary)
            ) {
                Icon(Icons.Default.Send, null, tint = Color.White)
            }
        }
        BottomNavBar("live_chat", onNavigate)
    }
}

// ─── Analytics ───────────────────────────────────────────────────────────────
@Composable
fun AnalyticsScreen(onNavigate: (String) -> Unit) {
    var refreshCount by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding().background(Background)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onNavigate("studio") }) {
                Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
            }
            Text("Live Analytics", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { refreshCount++ }) {
                Icon(Icons.Default.Refresh, null, tint = TextMuted)
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            StatCard("5,902", "Total Viewers", Success)
            StatCard("6,120", "Peak Viewers", Primary)
            StatCard("12.4 hrs", "Watch Time", Warning)
        }

        Spacer(Modifier.height(20.dp))
        Text("Per Platform", color = TextSecondary, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(10.dp))

        MockData.platforms.forEach { p ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Surface)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(p.displayName, color = TextPrimary, modifier = Modifier.weight(1f))
                Text("${p.viewerCount}", color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text("↑ +${(p.viewerCount * 0.1).toInt()}", color = Success, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(160.dp)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Surface),
            contentAlignment = Alignment.Center
        ) {
            Text("Viewers (Last 60 minutes)\nData refreshed $refreshCount time(s). Connect a platform API for live metrics.", color = TextMuted, fontSize = 13.sp)
        }

        Spacer(Modifier.weight(1f))
        BottomNavBar("studio", onNavigate)
    }
}

@Composable
private fun StatCard(value: String, label: String, accent: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Surface)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(label, color = TextMuted, fontSize = 11.sp)
    }
}

// ─── Scenes ──────────────────────────────────────────────────────────────────
@Composable
fun ScenesScreen(onNavigate: (String) -> Unit) {
    var activeId by remember { mutableStateOf("1") }
    var editing by remember { mutableStateOf(false) }
    var transition by remember { mutableStateOf("Fade (300ms)") }
    var customSceneCount by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().statusBarsPadding().background(Background)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onNavigate("studio") }) {
                Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
            }
            Text("Scenes", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { editing = !editing }) { Text(if (editing) "Done" else "Edit", color = Primary) }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(MockData.scenes) { scene ->
                val isActive = scene.id == activeId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isActive) Primary.copy(0.15f) else Surface)
                        .padding(14.dp)
                        .clickable { activeId = scene.id },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            when (scene.type) {
                                "camera" -> Icons.Default.Videocam
                                "karaoke" -> Icons.Default.MusicNote
                                "youtube" -> Icons.Default.PlayArrow
                                "screen" -> Icons.Default.ScreenShare
                                "brb" -> Icons.Default.Coffee
                                "ending" -> Icons.Default.WavingHand
                                else -> Icons.Default.Layers
                            },
                            null,
                            tint = if (isActive) Primary else TextMuted
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "${scene.id}. ${scene.name}",
                        color = TextPrimary,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                    if (isActive) {
                        Text("LIVE", color = LiveRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    } else if (editing) {
                        IconButton(onClick = { activeId = scene.id }) { Icon(Icons.Default.PlayArrow, null, tint = Primary) }
                    }
                    Icon(Icons.Default.MoreVert, null, tint = TextMuted)
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { customSceneCount++ },
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text(if (customSceneCount == 0) "Add Scene" else "Add Scene +$customSceneCount")
            }
            OutlinedButton(
                onClick = { transition = if (transition.startsWith("Fade")) "Cut (0ms)" else "Fade (300ms)" },
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(transition)
            }
        }
        BottomNavBar("studio", onNavigate)
    }
}

// ─── Remote Control ──────────────────────────────────────────────────────────
@Composable
fun RemoteControlScreen(onNavigate: (String) -> Unit) {
    var remoteStatus by remember { mutableStateOf("Demo mode — no remote host connected") }
    var micMuted by remember { mutableStateOf(false) }
    var lightsOn by remember { mutableStateOf(true) }
    var chatVisible by remember { mutableStateOf(true) }
    var sceneIndex by remember { mutableIntStateOf(1) }
    Column(Modifier.fillMaxSize().statusBarsPadding().background(Background)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onNavigate("home") }) {
                Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
            }
            Text("Remote Control", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Warning))
                Spacer(Modifier.width(6.dp))
                Text("Demo", color = Warning, fontSize = 13.sp)
            }
        }

        // Live status
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.clip(RoundedCornerShape(6.dp)).background(LiveRed).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text("● LIVE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text("--:--:--", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
        }

        Spacer(Modifier.height(24.dp))

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { remoteStatus = "Demo: Start command not sent to a remote host" },
                modifier = Modifier.weight(1f).height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Success)
            ) { Text("▶ Start All", fontWeight = FontWeight.Bold) }
            Button(
                onClick = { remoteStatus = "Demo: Stop command not sent to a remote host" },
                modifier = Modifier.weight(1f).height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LiveRed)
            ) { Text("■ Stop All", fontWeight = FontWeight.Bold) }
        }

        Spacer(Modifier.height(20.dp))

        val actions = listOf(
            Icons.Default.SkipNext to "Next Scene",
            Icons.Default.SkipPrevious to "Previous Scene",
            (if (micMuted) Icons.Default.Mic else Icons.Default.MicOff) to (if (micMuted) "Unmute Mic" else "Mute Mic"),
            Icons.Default.Camera to "Screenshot",
            Icons.Default.FiberManualRecord to "Record Clip",
            (if (chatVisible) Icons.Default.Chat else Icons.Default.ChatBubbleOutline) to (if (chatVisible) "Hide Chat" else "Show Chat"),
            (if (lightsOn) Icons.Default.Lightbulb else Icons.Default.Lightbulb) to (if (lightsOn) "Lights Off" else "Lights On")
        )

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            actions.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (icon, label) ->
                        OutlinedButton(
                            onClick = {
                                remoteStatus = when {
                                    label == "Next Scene" -> { sceneIndex = (sceneIndex % 7) + 1; "Scene $sceneIndex selected" }
                                    label == "Previous Scene" -> { sceneIndex = if (sceneIndex <= 1) 7 else sceneIndex - 1; "Scene $sceneIndex selected" }
                                    label == "Mute Mic" -> { micMuted = true; "Microphone muted" }
                                    label == "Unmute Mic" -> { micMuted = false; "Microphone unmuted" }
                                    label == "Screenshot" -> "Demo: Screenshot command not sent"
                                    label == "Record Clip" -> "Demo: Clip recording command not sent"
                                    label == "Hide Chat" -> { chatVisible = false; "Chat hidden" }
                                    label == "Show Chat" -> { chatVisible = true; "Chat shown" }
                                    label == "Lights Off" -> { lightsOn = false; "Lights off" }
                                    else -> { lightsOn = true; "Lights on" }
                                }
                            },
                            modifier = Modifier.weight(1f).height(52.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(icon, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(label, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(remoteStatus, color = Success, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { remoteStatus = "AI assistant is a UI placeholder; connect a provider before enabling execution" },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
        ) {
            Icon(Icons.Default.AutoAwesome, null)
            Spacer(Modifier.width(8.dp))
            Text("AI Assistant", fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.weight(1f))
        BottomNavBar("home", onNavigate)
    }
}
