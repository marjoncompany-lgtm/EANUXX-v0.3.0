package com.eanuxx.livestream.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.ui.theme.*

@Composable
fun NeonBackdrop(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier.background(
            Brush.verticalGradient(
                listOf(Background, BackgroundElevated, Background)
            )
        )
    ) {
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset(x = 90.dp, y = (-70).dp)
                .size(230.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Primary.copy(alpha = .22f), Color.Transparent)))
        )
        Box(
            Modifier
                .align(Alignment.TopStart)
                .offset(x = (-100).dp, y = 170.dp)
                .size(250.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(AccentPink.copy(alpha = .12f), Color.Transparent)))
        )
        content()
    }
}

@Composable
fun EanuxxBrand(modifier: Modifier = Modifier, compact: Boolean = false) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(if (compact) 38.dp else 44.dp)
                .shadow(12.dp, RoundedCornerShape(13.dp))
                .clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(Primary, AccentPurple, AccentPink))),
            contentAlignment = Alignment.Center
        ) {
            Text("E", color = Color.White, fontSize = if (compact) 19.sp else 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(11.dp))
        Column {
            Text("EANUXX", color = TextPrimary, fontSize = if (compact) 17.sp else 19.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            Text("LIVESTREAMING STUDIO", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp)
        }
    }
}

@Composable
fun StudioCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(SurfaceGlass, Surface)))
            .border(1.dp, CardBorder, RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Primary)
    ) {
        Text(text, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, letterSpacing = .4.sp)
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = Primary,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = containerColor)
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun DangerButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = LiveRed)
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun StatusDot(connected: Boolean, accent: Color = Success) {
    Box(
        modifier = Modifier.size(8.dp).clip(CircleShape).background(if (connected) accent else TextMuted)
    )
}

@Composable
fun PlatformChip(name: String, connected: Boolean, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(SurfaceVariant)
            .border(1.dp, color.copy(alpha = .18f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        StatusDot(connected, color)
        Spacer(Modifier.width(7.dp))
        Text(name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        if (action != null && onAction != null) {
            TextButton(onClick = onAction) { Text(action, color = AccentCyan, fontSize = 12.sp) }
        }
    }
}

@Composable
fun QuickActionTile(icon: ImageVector, label: String, onClick: () -> Unit, accent: Color = Primary) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(17.dp))
            .background(SurfaceGlass)
            .border(1.dp, CardBorder, RoundedCornerShape(17.dp))
            .clickable(onClick = onClick)
            .padding(13.dp)
            .width(92.dp)
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(accent.copy(alpha = .13f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = accent, modifier = Modifier.size(23.dp)) }
        Spacer(Modifier.height(8.dp))
        Text(label, color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun MetricCard(
    label: String,
    value: String,
    change: String? = null,
    icon: ImageVector = Icons.Default.Insights,
    modifier: Modifier = Modifier
) {
    StudioCard(modifier.widthIn(min = 0.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = AccentCyan, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(7.dp))
            Text(label, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(7.dp))
        Text(value, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        if (change != null) Text(change, color = Success, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BottomNavBar(currentRoute: String, onNavigate: (String) -> Unit) {
    val items = listOf(
        Triple("home", "Home", Icons.Default.Home),
        Triple("studio", "Studio", Icons.Default.Videocam),
        Triple("entertainment", "Create", Icons.Default.AddCircle),
        Triple("live_chat", "Activity", Icons.Default.Notifications),
        Triple("settings", "Profile", Icons.Default.Person)
    )
    NavigationBar(
        containerColor = Color(0xF5090D17),
        tonalElevation = 0.dp,
        modifier = Modifier.border(1.dp, CardBorder.copy(alpha = .55f))
    ) {
        items.forEach { (route, label, icon) ->
            val selected = currentRoute == route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(route) },
                icon = { Icon(icon, label, tint = if (selected) AccentCyan else TextMuted, modifier = Modifier.size(21.dp)) },
                label = { Text(label, fontSize = 10.sp, color = if (selected) TextPrimary else TextMuted, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Primary.copy(alpha = .13f),
                    selectedIconColor = AccentCyan,
                    unselectedIconColor = TextMuted
                )
            )
        }
    }
}
