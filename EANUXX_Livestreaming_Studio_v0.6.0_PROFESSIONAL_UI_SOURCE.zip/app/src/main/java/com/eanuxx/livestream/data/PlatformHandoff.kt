package com.eanuxx.livestream.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import java.security.SecureRandom

/**
 * Approval-based platform handoff for all five supported platforms.
 *
 * EANUXX never reads another app's private data. A platform must explicitly
 * return the RTMP/server URL and stream key through the callback. Until a
 * real platform OAuth/API integration is configured, the external destination
 * is the platform's official live/creator page and manual entry remains the
 * supported fallback.
 */
object PlatformHandoff {
    const val CALLBACK_SCHEME = "eanuxx"
    const val CALLBACK_HOST = "platform"
    private const val PREFS = "eanuxx_platform_handoff"
    private const val NONCE_PREFIX = "nonce_"
    private const val NONCE_BYTES = 24

    data class PlatformSpec(
        val id: String,
        val name: String,
        val serverKey: String,
        val streamKey: String,
        val launchUrl: String,
        val appPackage: String? = null
    )

    data class Result(
        val platformId: String,
        val serverUrl: String,
        val streamKey: String
    )

    val platforms = listOf(
        PlatformSpec("yt", "YouTube", "youtube_server_url", "youtube_stream_key", "https://studio.youtube.com/channel/UC/live", "com.google.android.youtube"),
        PlatformSpec("fb", "Facebook", "facebook_server_url", "facebook_stream_key", "https://www.facebook.com/live/producer/", "com.facebook.katana"),
        PlatformSpec("ig", "Instagram", "instagram_server_url", "instagram_stream_key", "https://www.instagram.com/", "com.instagram.android"),
        PlatformSpec("tt", "TikTok", "tiktok_server_url", "tiktok_stream_key", "https://www.tiktok.com/live/creator", null),
        PlatformSpec("x", "X", "x_server_url", "x_stream_key", "https://studio.x.com/", null)
    )

    fun spec(id: String): PlatformSpec? = platforms.firstOrNull { it.id == id }

    fun callbackUri(platformId: String, nonce: String): Uri = Uri.Builder()
        .scheme(CALLBACK_SCHEME)
        .authority(CALLBACK_HOST)
        .appendPath(platformId)
        .appendQueryParameter("nonce", nonce)
        .build()

    private fun createPendingNonce(context: Context, platformId: String): String {
        val bytes = ByteArray(NONCE_BYTES)
        SecureRandom().nextBytes(bytes)
        val nonce = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(NONCE_PREFIX + platformId, nonce).apply()
        return nonce
    }

    private fun clearPendingNonce(context: Context, platformId: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(NONCE_PREFIX + platformId).apply()
    }

    fun launch(context: Context, platformId: String): Boolean {
        val p = spec(platformId) ?: return false
        val nonce = createPendingNonce(context, platformId)
        val callback = callbackUri(platformId, nonce).toString()
        val uri = Uri.parse(p.launchUrl + (if (p.launchUrl.contains("?")) "&" else "?") + "eanuxx_return=${Uri.encode(callback)}")

        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                p.appPackage?.let { setPackage(it) }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            clearPendingNonce(context, platformId)
            false
        }
    }

    fun parseAndValidate(context: Context, uri: Uri?): Result? {
        if (uri == null || !uri.scheme.equals(CALLBACK_SCHEME, true) ||
            !uri.host.equals(CALLBACK_HOST, true) || uri.pathSegments.size != 1) return null

        val platformId = uri.pathSegments[0]
        val p = spec(platformId) ?: return null
        val expected = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(NONCE_PREFIX + platformId, null) ?: return null
        val returned = uri.getQueryParameter("nonce") ?: return null
        if (!constantTimeEquals(expected, returned)) {
            clearPendingNonce(context, platformId)
            return null
        }

        val serverUrl = firstNonBlank(uri.getQueryParameter("server_url"), uri.getQueryParameter("serverUrl")) ?: return null
        val streamKey = firstNonBlank(uri.getQueryParameter("stream_key"), uri.getQueryParameter("streamKey")) ?: return null
        val normalizedUrl = serverUrl.trim()
        val normalizedKey = streamKey.trim()
        if (!normalizedUrl.startsWith("https://", true) || normalizedKey.length < 8) return null

        clearPendingNonce(context, platformId)
        return Result(platformId, normalizedUrl, normalizedKey)
    }

    private fun firstNonBlank(vararg values: String?): String? = values.firstOrNull { !it.isNullOrBlank() }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }
}
