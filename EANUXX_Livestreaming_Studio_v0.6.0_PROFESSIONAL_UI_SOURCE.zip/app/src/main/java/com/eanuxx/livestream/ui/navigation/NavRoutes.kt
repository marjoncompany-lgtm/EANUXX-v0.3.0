package com.eanuxx.livestream.ui.navigation

sealed class Screen(val route: String) {
    object Permissions : Screen("permissions")
    object Auth : Screen("auth")
    object Home : Screen("home")
    object Studio : Screen("studio")
    object Entertainment : Screen("entertainment")
    object AudioDevices : Screen("audio_devices")
    object LiveChat : Screen("live_chat")
    object Analytics : Screen("analytics")
    object Scenes : Screen("scenes")
    object RemoteControl : Screen("remote_control")
    object Settings : Screen("settings")
}
