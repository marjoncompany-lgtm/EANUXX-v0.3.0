package com.eanuxx.livestream.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import com.eanuxx.livestream.data.MockData
import com.eanuxx.livestream.ui.components.*
import com.eanuxx.livestream.ui.theme.*

@Composable
fun StudioScreen(onNavigate: (String) -> Unit, isLive: Boolean, liveElapsedSeconds: Long, onToggleLive: () -> Unit) {
    var showStopConfirm by remember { mutableStateOf(false) }
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }

    NeonBackdrop(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("PRODUCTION CONTROL", color = AccentCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Studio", color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.width(9.dp))
                        if (isLive) {
                            Box(Modifier.clip(RoundedCornerShape(7.dp)).background(LiveRed).padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text("● LIVE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Success))
                        Spacer(Modifier.width(6.dp))
                        Text("GOOD", color = Success, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    if (isLive) Text(formatDuration(liveElapsedSeconds), color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column(Modifier.weight(1f).padding(horizontal = 14.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                Box(
                    Modifier.fillMaxWidth().height(238.dp).clip(RoundedCornerShape(24.dp)).border(1.dp, Color.White.copy(.10f), RoundedCornerShape(24.dp))
                ) {
                    CameraPreview(Modifier.fillMaxSize(), lensFacing)
                    Box(Modifier.fillMaxWidth().height(60.dp).align(Alignment.TopCenter).background(Brush.verticalGradient(listOf(Color.Black.copy(.60f), Color.Transparent))))
                    Row(Modifier.align(Alignment.TopStart).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(if (isLive) LiveRed else Success))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isLive) "ON AIR" else "PREVIEW", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                    IconButton(onClick = { lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK }, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)) {
                        Icon(Icons.Default.Cameraswitch, "Switch camera", tint = Color.White)
                    }
                    Row(Modifier.align(Alignment.BottomStart).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PreviewTag("1080P")
                        PreviewTag("30 FPS")
                        PreviewTag("H.264")
                    }
                }

                Spacer(Modifier.height(13.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                    MetricCard("VIEWERS", MockData.totalViewers.toString(), "Live", Icons.Default.Visibility, Modifier.weight(1f))
                    MetricCard("BITRATE", "6.2", "Mbps", Icons.Default.Speed, Modifier.weight(1f))
                    MetricCard("FPS", "30", "Stable", Icons.Default.Timeline, Modifier.weight(1f))
                }

                Spacer(Modifier.height(16.dp))
                SectionHeader("Destinations", "Manage") { onNavigate("settings") }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                    MockData.platforms.forEach { p ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(SurfaceGlass).border(1.dp, CardBorder, RoundedCornerShape(13.dp)).padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(Color(p.color)))
                            Spacer(Modifier.height(5.dp))
                            Text(p.name.take(3).uppercase(), color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text(if (p.isConnected) "ON" else "OFF", color = if (p.isConnected) Success else TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                SectionHeader("Quick Controls")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    ControlTile(Icons.Default.Layers, "Scenes", Modifier.weight(1f)) { onNavigate("scenes") }
                    ControlTile(Icons.Default.Source, "Source", Modifier.weight(1f)) { onNavigate("entertainment") }
                    ControlTile(Icons.Default.Mic, "Audio", Modifier.weight(1f)) { onNavigate("audio_devices") }
                    ControlTile(Icons.Default.Analytics, "Stats", Modifier.weight(1f)) { onNavigate("analytics") }
                }
                Spacer(Modifier.height(20.dp))
            }

            Box(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                if (isLive) DangerButton("■  STOP ALL BROADCASTS", { showStopConfirm = true })
                else Button(
                    onClick = onToggleLive,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(17.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Primary)
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(7.dp))
                    Text("START ALL DESTINATIONS", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                }
            }
            BottomNavBar("studio", onNavigate)
        }
    }

    if (showStopConfirm) {
        AlertDialog(
            onDismissRequest = { showStopConfirm = false },
            title = { Text("Stop All Broadcasts?") },
            text = { Text("This will stop streaming to every active destination.") },
            confirmButton = { TextButton(onClick = { showStopConfirm = false; onToggleLive() }) { Text("Stop All", color = LiveRed) } },
            dismissButton = { TextButton(onClick = { showStopConfirm = false }) { Text("Cancel") } },
            containerColor = Surface, titleContentColor = TextPrimary, textContentColor = TextSecondary
        )
    }
}

@Composable
private fun PreviewTag(text: String) {
    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(.55f)).padding(horizontal = 7.dp, vertical = 4.dp)) {
        Text(text, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ControlTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(15.dp)).background(SurfaceGlass).border(1.dp, CardBorder, RoundedCornerShape(15.dp))
            .clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = AccentCyan, modifier = Modifier.size(21.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun formatDuration(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

@Composable
private fun CameraPreview(modifier: Modifier = Modifier, lensFacing: Int = CameraSelector.LENS_FACING_BACK) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    Box(modifier = modifier.background(SurfaceVariant), contentAlignment = Alignment.Center) {
        if (hasPermission) {
            key(lensFacing) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val provider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also { it.surfaceProvider = surfaceProvider }
                                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                                try {
                                    provider.unbindAll()
                                    provider.bindToLifecycle(lifecycleOwner, selector, preview)
                                } catch (_: Exception) { }
                            }, ContextCompat.getMainExecutor(ctx))
                        }
                    }
                )
            }
        } else {
            Icon(Icons.Default.VideocamOff, null, tint = TextMuted, modifier = Modifier.size(42.dp))
            Text("Camera permission required", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 72.dp))
        }
    }
}
