# EANUXX v0.6.0 — Five-Platform Auto-Fill Status

The Platforms screen now treats YouTube, Facebook, Instagram, TikTok and X consistently: each has an approval-first **Connect / Auto-Fill** action, secure local storage, and a manual Server URL / Stream Key fallback.

## Important production rule

EANUXX must not scrape another app or pretend that a website query parameter is an official API. A stream key is sensitive credential material. The app accepts it only from an authorized integration or from explicit manual entry.

## Current platform capability

| Platform | Automatic live setup | Requirement |
|---|---|---|
| YouTube | Supported by the official Live Streaming API architecture | Google OAuth client configuration + YouTube Live API authorization. The API can create a `liveStream` and exposes the stream's CDN/ingestion configuration. |
| Facebook | Supported where the authorized Meta Live Video API permissions/account eligibility allow it | Meta developer app, user/page authorization, required permissions/review, and current Live Video API access. |
| Instagram | Conditional | Meta developer app, Instagram professional account eligibility, required authorization/scopes and current Instagram Live API availability. |
| TikTok | Conditional | TikTok Login Kit/API authorization and any Live API product approval/review required for the account/app. |
| X | Manual fallback | No current official X Live ingest API was confirmed in the current developer documentation reviewed for this release. |

## Credentials

Never put platform client secrets in the Android APK. OAuth code exchange that requires a client secret should be performed by a secure backend. Access/refresh tokens should be stored securely and revoked when the user disconnects an account.

## UI behavior

1. User selects a platform.
2. User taps **Connect / Auto-Fill**.
3. EANUXX asks for approval.
4. The official authorization/integration flow is used when configured.
5. If the platform returns an authorized Server URL + Stream Key, EANUXX validates them and stores them with Android Keystore AES-GCM.
6. If automatic setup is unavailable, the user can enter the values manually.

This release intentionally does not fabricate successful platform callbacks for unsupported APIs.
