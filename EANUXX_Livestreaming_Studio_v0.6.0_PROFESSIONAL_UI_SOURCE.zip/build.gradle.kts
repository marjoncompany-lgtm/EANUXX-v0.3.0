// AGP 9 uses built-in Kotlin. We deliberately do NOT apply
// org.jetbrains.kotlin.android to the Android module.
// This classpath opts the built-in Kotlin integration into a stable
// newer Kotlin Gradle Plugin version compatible with this project.
buildscript {
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.3.21")
    }
}

plugins {
    id("com.android.application") version "9.4.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
