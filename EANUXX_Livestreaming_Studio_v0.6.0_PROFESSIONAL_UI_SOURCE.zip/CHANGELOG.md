# EANUXX v0.6.0 — Professional UI Update

- Extravagant dark studio visual system with neon cyan/purple/pink accents.
- Premium EANUXX brand header and production-status indicators.
- Redesigned Home dashboard with Quick Launch hero, production tools, destinations and live metrics.
- Redesigned Studio control room with camera preview frame, health metrics, destination status and quick controls.
- Glass-style cards, stronger hierarchy, refined spacing, borders and touch targets.
- Existing platform connection/Auto-Fill architecture retained.
- Existing package identity retained for update compatibility.

Previous functionality and platform-specific limitations remain unchanged.
