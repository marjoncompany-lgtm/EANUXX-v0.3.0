# EANUXX Update Signing Policy

For every update intended to install over an existing EANUXX installation:

1. Keep applicationId exactly `com.wEANUXX_20148007`.
2. Increase versionCode above the installed version.
3. Keep the same signing certificate/key alias `eanuxx`.
4. Keep the existing `EANUXX_KEYSTORE_BASE64` and `EANUXX_KEYSTORE_PASSWORD` GitHub Actions secrets.
5. Enable APK Signature Scheme V1, V2 and V3.
6. Align the APK before signing.
7. Keep `resources.arsc` uncompressed and verify ZIP alignment.
8. Verify package, versionCode, versionName and certificate before publishing the artifact.

The current professional update is:

- versionCode: `5`
- versionName: `0.4.0-professional-update`
- package: `com.wEANUXX_20148007`

Never create a new certificate for an update. A different certificate will prevent Android from treating the APK as an update to the existing installation.

The app's Android Keystore-backed stream settings are retained by Android across a normal package update. Uninstalling the app can remove app-private data and should not be used as part of the normal update process.
