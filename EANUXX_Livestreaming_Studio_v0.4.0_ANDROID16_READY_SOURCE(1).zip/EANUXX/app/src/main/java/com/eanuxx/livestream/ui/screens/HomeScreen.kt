package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.data.MockData
import com.eanuxx.livestream.ui.components.*
import com.eanuxx.livestream.ui.theme.*

@Composable
fun HomeScreen(
    onNavigate: (String) -> Unit,
    onStartAll: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize().statusBarsPadding()
            .background(Background)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("E", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("EANUXX", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Go Live Everywhere", color = TextMuted, fontSize = 12.sp)
                }
            }
            Icon(Icons.Default.WorkspacePremium, null, tint = Warning, modifier = Modifier.size(28.dp))
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            // Quick actions
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(listOf(Primary, PrimaryVariant))
                        )
                        .clickableNoRipple { onStartAll() }
                        .padding(20.dp)
                ) {
                    Column {
                        Icon(Icons.Default.RocketLaunch, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Quick Go Live", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Auto Setup & Start", color = Color.White.copy(0.8f), fontSize = 12.sp)
                    }
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Surface)
                        .clickableNoRipple { onNavigate("studio") }
                        .padding(20.dp)
                ) {
                    Column {
                        Icon(Icons.Default.Tune, null, tint = Primary, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Studio Mode", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Advanced Control", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // Feature tiles
            val tiles = listOf(
                Triple(Icons.Default.Videocam, "Camera", "studio"),
                Triple(Icons.Default.ScreenShare, "Screen", "entertainment"),
                Triple(Icons.Default.LiveTv, "Entertainment", "entertainment"),
                Triple(Icons.Default.Stream, "Multistream", "studio"),
                Triple(Icons.Default.Chat, "Chat", "live_chat"),
                Triple(Icons.Default.Analytics, "Analytics", "analytics")
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.height(220.dp),
                userScrollEnabled = false
            ) {
                items(tiles) { (icon, label, route) ->
                    QuickActionTile(icon, label, onClick = { onNavigate(route) })
                }
            }

            Spacer(Modifier.height(24.dp))

            SectionHeader("Connected Platforms", "Manage Accounts") {
                onNavigate("settings")
            }
            Spacer(Modifier.height(10.dp))

            MockData.platforms.chunked(2).forEach { row ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    row.forEach { p ->
                        PlatformChip(
                            name = p.displayName,
                            connected = p.isConnected,
                            color = Color(p.color)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(28.dp))
            PrimaryButton("▶  START ALL", onClick = onStartAll)
            Spacer(Modifier.height(20.dp))
        }

        BottomNavBar(currentRoute = "home", onNavigate = onNavigate)
    }
}

@Composable
private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.then(
        Modifier.clickable(
            indication = null,
            interactionSource = remember { MutableInteractionSource() },
            onClick = onClick
        )
    )
