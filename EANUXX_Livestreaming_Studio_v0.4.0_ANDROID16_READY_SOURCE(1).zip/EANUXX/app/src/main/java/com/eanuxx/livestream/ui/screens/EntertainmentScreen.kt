package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.view.View
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.ui.components.BottomNavBar
import com.eanuxx.livestream.ui.components.PrimaryButton
import com.eanuxx.livestream.ui.theme.*

@Composable
fun EntertainmentScreen(onNavigate: (String) -> Unit) {
    var url by remember { mutableStateOf("https://www.youtube.com") }
    var volume by remember { mutableFloatStateOf(0.7f) }
    var fitToScreen by remember { mutableStateOf(true) }
    var pip by remember { mutableStateOf(false) }
    var loadUrl by remember { mutableStateOf("https://www.youtube.com") }
    var status by remember { mutableStateOf("Ready") }

    val tabs = listOf("YouTube", "Karaoke", "Browser", "Screen", "Apps")
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize().statusBarsPadding()
            .background(Background)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onNavigate("studio") }) {
                Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
            }
            Text("Entertainment Box", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.HelpOutline, null, tint = TextMuted)
        }

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Background,
            contentColor = Primary,
            edgePadding = 12.dp
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontSize = 13.sp) }
                )
            }
        }

        // URL bar
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Link, null) },
            trailingIcon = {
                IconButton(onClick = {
                    val normalized = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
                    url = normalized
                    loadUrl = normalized
                    status = "Loading…"
                }) {
                    Icon(Icons.Default.Search, null)
                }
            },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Primary,
                unfocusedBorderColor = CardBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        // Real web content for YouTube/Browser tabs.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(SurfaceVariant)
        ) {
            if (selectedTab == 0 || selectedTab == 2) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        WebView(context).apply {
                            visibility = View.VISIBLE
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, pageUrl: String?) {
                                    status = "Loaded"
                                }
                            }
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            loadUrl(loadUrl)
                        }
                    },
                    update = { view ->
                        if (view.url != loadUrl) view.loadUrl(loadUrl)
                    }
                )
            } else {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.PlayCircle, null, tint = TextMuted, modifier = Modifier.size(48.dp))
                    Text(
                        when (selectedTab) {
                            1 -> "Karaoke source ready"
                            3 -> "Use Android screen capture from Studio"
                            else -> "App source ready"
                        },
                        color = TextMuted
                    )
                    Text("Status: $status", color = TextMuted, fontSize = 11.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { status = "Source queued for live output" },
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) {
                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Send to Live", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { status = "Source added to current scene" },
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Add to Scene")
            }
        }

        Spacer(Modifier.height(20.dp))

        // Volume
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.VolumeUp, null, tint = TextSecondary)
            Slider(
                value = volume,
                onValueChange = { volume = it },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(thumbColor = Primary, activeTrackColor = Primary)
            )
            Text("${(volume * 100).toInt()}%", color = TextSecondary, fontSize = 13.sp)
        }

        // Toggles
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Fit to Screen", color = TextPrimary)
            Switch(checked = fitToScreen, onCheckedChange = { fitToScreen = it },
                colors = SwitchDefaults.colors(checkedTrackColor = Primary))
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Picture in Picture", color = TextPrimary)
            Switch(checked = pip, onCheckedChange = { pip = it },
                colors = SwitchDefaults.colors(checkedTrackColor = Primary))
        }

        Spacer(Modifier.height(6.dp))
        Text(status, color = Success, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.weight(1f))
        BottomNavBar(currentRoute = "entertainment", onNavigate = onNavigate)
    }
}
