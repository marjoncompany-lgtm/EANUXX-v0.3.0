package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.eanuxx.livestream.data.SecureStore
import com.eanuxx.livestream.data.AppPrefs
import com.eanuxx.livestream.ui.components.BottomNavBar
import com.eanuxx.livestream.ui.theme.*

@Composable
fun SettingsScreen(onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    val secureStore = remember { SecureStore(context) }
    val appPrefs = remember { AppPrefs(context) }
    var dialogSection by remember { mutableStateOf<String?>(null) }
    var serverUrl by remember { mutableStateOf(secureStore.get("facebook_server_url")) }
    var streamKey by remember { mutableStateOf(secureStore.get("facebook_stream_key")) }
    var saveError by remember { mutableStateOf("") }

    val sections = listOf(
        "Camera" to Icons.Default.Videocam,
        "Audio" to Icons.Default.Mic,
        "Devices" to Icons.Default.Devices,
        "Streaming" to Icons.Default.Stream,
        "Platforms" to Icons.Default.Link,
        "Metadata & Hashtags" to Icons.Default.Tag,
        "Scenes" to Icons.Default.Layers,
        "Recording" to Icons.Default.FiberManualRecord,
        "Notifications" to Icons.Default.Notifications,
        "Account / Security" to Icons.Default.Security,
        "Permissions & Privacy" to Icons.Default.PrivacyTip,
        "Advanced" to Icons.Default.Tune
    )

    Column(Modifier.fillMaxSize().statusBarsPadding().background(Background)) {
        Text("Settings", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(20.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            sections.forEach { (title, icon) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface)
                        .clickable { dialogSection = title }.padding(14.dp).padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, null, tint = Primary, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(title, color = TextPrimary, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("EANUXX  •  v0.4.0-professional", color = TextMuted, fontSize = 12.sp)
            Text("Created by Marjon Sealza", color = TextMuted, fontSize = 12.sp)
            Text("Free access • No subscription required", color = Success, fontSize = 12.sp)
            Spacer(Modifier.height(24.dp))
        }
        BottomNavBar("settings", onNavigate)
    }

    if (dialogSection != null) {
        val title = dialogSection!!
        AlertDialog(
            onDismissRequest = { dialogSection = null },
            title = { Text(title) },
            text = {
                when (title) {
                    "Platforms", "Streaming" -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Facebook Live Producer", fontWeight = FontWeight.Bold)
                        OutlinedTextField(value = serverUrl, onValueChange = { serverUrl = it }, label = { Text("Server URL") }, singleLine = true)
                        OutlinedTextField(
                            value = streamKey,
                            onValueChange = { streamKey = it },
                            label = { Text("Stream Key") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                        if (saveError.isNotEmpty()) Text(saveError, color = LiveRed, fontSize = 12.sp)
                        Text("The stream key is encrypted with Android Keystore and remains on this device.", color = TextMuted, fontSize = 12.sp)
                    }
                    "Advanced" -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Auto reconnect", color = TextPrimary)
                                Text("Retry after a temporary network drop.", color = TextMuted, fontSize = 12.sp)
                            }
                            Switch(checked = appPrefs.autoReconnect, onCheckedChange = { appPrefs.autoReconnect = it })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Low latency mode", color = TextPrimary)
                                Text("Prefer faster live response when supported.", color = TextMuted, fontSize = 12.sp)
                            }
                            Switch(checked = appPrefs.lowLatency, onCheckedChange = { appPrefs.lowLatency = it })
                        }
                    }
                    else -> Text("Device-specific controls appear when supported by Android. EANUXX keeps unsupported controls disabled rather than pretending they are active.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title == "Platforms" || title == "Streaming") {
                        val normalized = serverUrl.trim()
                        if (normalized.isNotEmpty() && !normalized.startsWith("https://")) {
                            saveError = "Server URL must use HTTPS."
                            return@TextButton
                        }
                        if (streamKey.isNotBlank() && streamKey.trim().length < 8) {
                            saveError = "Stream key looks too short."
                            return@TextButton
                        }
                        secureStore.put("facebook_server_url", normalized)
                        secureStore.put("facebook_stream_key", streamKey.trim())
                    }
                    saveError = ""
                    dialogSection = null
                }) { Text("Save", color = Primary) }
            },
            dismissButton = {
                TextButton(onClick = { dialogSection = null }) { Text("Close") }
            },
            containerColor = Surface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }
}
