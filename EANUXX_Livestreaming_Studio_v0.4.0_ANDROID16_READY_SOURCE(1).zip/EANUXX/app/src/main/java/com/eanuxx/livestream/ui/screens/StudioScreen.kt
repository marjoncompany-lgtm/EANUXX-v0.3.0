package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.data.MockData
import com.eanuxx.livestream.ui.components.BottomNavBar
import com.eanuxx.livestream.ui.components.DangerButton
import com.eanuxx.livestream.ui.theme.*

@Composable
fun StudioScreen(
    onNavigate: (String) -> Unit,
    isLive: Boolean,
    liveElapsedSeconds: Long,
    onToggleLive: () -> Unit
) {
    var showStopConfirm by remember { mutableStateOf(false) }
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }

    Column(
        modifier = Modifier
            .fillMaxSize().statusBarsPadding()
            .background(Background)
    ) {
        // Live header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isLive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(LiveRed)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("● LIVE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(formatDuration(liveElapsedSeconds), color = TextPrimary, fontWeight = FontWeight.SemiBold)
                } else {
                    Text("Studio Preview", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Good", color = Success, fontSize = 13.sp)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.SignalCellularAlt, null, tint = Success, modifier = Modifier.size(18.dp))
            }
        }

        // Real CameraX preview. This replaces the former static placeholder.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp))
        ) {
            CameraPreview(
                modifier = Modifier.fillMaxSize(),
                lensFacing = lensFacing
            )
            IconButton(
                onClick = {
                    lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                        CameraSelector.LENS_FACING_FRONT
                    } else {
                        CameraSelector.LENS_FACING_BACK
                    }
                },
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
            ) {
                Icon(Icons.Default.Cameraswitch, "Switch camera", tint = Color.White)
            }
        }

        Spacer(Modifier.height(12.dp))

        // Viewer counts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            MockData.platforms.take(5).forEach { p ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(p.name.take(2).uppercase(), color = TextMuted, fontSize = 11.sp)
                    Text(
                        if (p.viewerCount > 999) "${p.viewerCount / 1000.0}K" else "${p.viewerCount}",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text("Total Viewers  ", color = TextSecondary, fontSize = 14.sp)
            Text("${MockData.totalViewers}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("  ↑ +488", color = Success, fontSize = 13.sp)
        }

        Spacer(Modifier.height(16.dp))

        // Source controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            SourceButton(Icons.Default.Videocam, "Camera") { onNavigate("studio") }
            SourceButton(Icons.Default.Mic, "Mic") { onNavigate("audio_devices") }
            SourceButton(Icons.Default.VolumeUp, "Speaker") { onNavigate("audio_devices") }
            SourceButton(Icons.Default.ScreenShare, "Screenshare") { onNavigate("entertainment") }
        }

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { onNavigate("scenes") },
                modifier = Modifier.weight(1f).height(44.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Layers, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Scenes")
            }
            OutlinedButton(
                onClick = { onNavigate("entertainment") },
                modifier = Modifier.weight(1f).height(44.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Source, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Source")
            }
        }

        Spacer(Modifier.weight(1f))

        // Stop / Start
        Box(modifier = Modifier.padding(16.dp)) {
            if (isLive) {
                DangerButton(text = "■  STOP ALL", onClick = { showStopConfirm = true })
            } else {
                Button(
                    onClick = onToggleLive,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Primary)
                ) {
                    Text("▶  START ALL", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }

        BottomNavBar(currentRoute = "studio", onNavigate = onNavigate)
    }

    if (showStopConfirm) {
        AlertDialog(
            onDismissRequest = { showStopConfirm = false },
            title = { Text("Stop All Broadcasts?") },
            text = { Text("This will stop streaming to every connected destination.") },
            confirmButton = {
                TextButton(onClick = {
                    showStopConfirm = false
                    onToggleLive()
                }) { Text("Stop All", color = LiveRed) }
            },
            dismissButton = {
                TextButton(onClick = { showStopConfirm = false }) { Text("Cancel") }
            },
            containerColor = Surface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }
}

private fun formatDuration(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

@Composable
private fun CameraPreview(
    modifier: Modifier = Modifier,
    lensFacing: Int = CameraSelector.LENS_FACING_BACK
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    Box(modifier = modifier.background(SurfaceVariant), contentAlignment = Alignment.Center) {
        if (hasPermission) {
            key(lensFacing) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val provider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also { it.surfaceProvider = surfaceProvider }
                                val selector = CameraSelector.Builder().setLensFacing(lensFacing).build()
                                try {
                                    provider.unbindAll()
                                    provider.bindToLifecycle(lifecycleOwner, selector, preview)
                                } catch (_: Exception) { }
                            }, ContextCompat.getMainExecutor(ctx))
                        }
                    }
                )
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.VideocamOff, null, tint = TextMuted, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(8.dp))
                Text("Camera permission required", color = TextMuted)
                Text("Open Permissions to enable the camera", color = TextMuted, fontSize = 12.sp)
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black.copy(0.6f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text("Program Output", color = Color.White, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SourceButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Surface)
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
            .width(64.dp)
    ) {
        Icon(icon, null, tint = TextPrimary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = TextSecondary, fontSize = 11.sp)
    }
}
