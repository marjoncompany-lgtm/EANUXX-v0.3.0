# EANUXX Livestreaming Studio — v0.4.0 Professional Update

Created by Marjon Sealza.

## Update safety
- Application ID remains `com.wEANUXX_20148007`.
- Version code is `5`, higher than the installed v0.3.1 build (version code 4).
- Future releases must be signed with the same EANUXX signing certificate.
- Android app data and the existing Android Keystore key are preserved during a normal update.
- Never generate a new signing certificate for an update.

## Improvements
- Update-safe versioning and migration marker.
- Existing installations no longer get trapped in the fake account login screen after updating.
- Runtime permission gate remains available when camera/microphone permissions are missing.
- CameraX preview remains real and now supports front/back camera switching.
- Camera preview is recreated only when the selected lens changes, avoiding unnecessary rebinding during the live timer.
- Facebook Live Producer server URL and stream key remain encrypted with Android Keystore.
- Stream key is masked in Settings.
- HTTPS validation prevents insecure Facebook server URLs from being saved.
- Basic stream-key validation prevents accidental short/empty values from being accepted.
- Auto-reconnect and low-latency preferences are persisted for future production media-engine integration.
- Settings version label updated to v0.4.0 Professional.

## Important capability note
This project is a professional Android control/UI foundation. Camera preview, local chat, scenes, audio controls, settings, secure storage, and entertainment WebView are implemented. Actual broadcast transport to Facebook/YouTube/TikTok/etc. still requires a real media encoder/output engine and the corresponding platform broadcast APIs or RTMP/SRT endpoints. The UI does not claim a broadcast is connected when that transport is not present.


## Android compatibility profile (v0.4.0)

- Minimum supported Android: API 26 (Android 8.0)
- Tested target baseline: Android 13 / API 33
- Current stable target: Android 16 / API 36
- compileSdk/targetSdk: 36
- AGP: 8.13.2
- Gradle: 8.13
- Java: 17
- Activity Compose: 1.13.0
- Core KTX: 1.19.0
- Lifecycle: 2.11.0
- CameraX: 1.6.2
- 16 KB page-size packaging is enabled/verified in the release workflow.

The project uses documented Android/AndroidX APIs, runtime permission version checks, and status-bar-safe edge-to-edge layouts. Newer Android versions should inherit the compatibility behavior of the documented APIs; every major Android release should still be regression-tested before publishing an update. Android 17 is currently a beta platform, not the stable production baseline.
