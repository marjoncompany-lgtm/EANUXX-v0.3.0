package com.eanuxx.livestream.ui.theme

import androidx.compose.ui.graphics.Color

val Background = Color(0xFF080B12)
val Surface = Color(0xFF111827)
val SurfaceVariant = Color(0xFF1F2937)
val Primary = Color(0xFF3B82F6)
val PrimaryVariant = Color(0xFF2563EB)
val LiveRed = Color(0xFFEF4444)
val Success = Color(0xFF22C55E)
val Warning = Color(0xFFF59E0B)
val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)
val CardBorder = Color(0xFF374151)
val YouTube = Color(0xFFFF0000)
val Facebook = Color(0xFF1877F2)
val Instagram = Color(0xFFE4405F)
val TikTok = Color(0xFF000000)
val XPlatform = Color(0xFF1DA1F2)
