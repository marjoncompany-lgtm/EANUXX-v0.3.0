package com.eanuxx.livestream

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import java.util.Locale
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.eanuxx.livestream.ui.navigation.Screen
import com.eanuxx.livestream.ui.screens.*
import com.eanuxx.livestream.ui.theme.Background
import com.eanuxx.livestream.ui.theme.EanuxxTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EanuxxTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Background) {
                    EanuxxApp()
                }
            }
        }
    }
}

@Composable
fun EanuxxApp() {
    val navController = rememberNavController()
    var isLive by remember { mutableStateOf(false) }
    var liveStartedAt by remember { mutableLongStateOf(0L) }
    var liveElapsedSeconds by remember { mutableLongStateOf(0L) }

    LaunchedEffect(isLive, liveStartedAt) {
        while (isLive) {
            liveElapsedSeconds = ((System.currentTimeMillis() - liveStartedAt) / 1000L).coerceAtLeast(0L)
            delay(1000L)
        }
    }

    fun navigate(route: String) {
        navController.navigate(route) {
            launchSingleTop = true
            restoreState = true
        }
    }

    NavHost(
        navController = navController,
        startDestination = Screen.Permissions.route
    ) {
        composable(Screen.Permissions.route) {
            PermissionsScreen(onContinue = {
                navController.navigate(Screen.Auth.route) {
                    popUpTo(Screen.Permissions.route) { inclusive = true }
                }
            })
        }
        composable(Screen.Auth.route) {
            AuthScreen(onAuthenticated = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Auth.route) { inclusive = true }
                }
            })
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigate = { navigate(it) },
                onStartAll = {
                    if (!isLive) {
                        liveStartedAt = System.currentTimeMillis()
                        liveElapsedSeconds = 0L
                        isLive = true
                    }
                    navigate(Screen.Studio.route)
                }
            )
        }
        composable(Screen.Studio.route) {
            StudioScreen(
                onNavigate = { navigate(it) },
                isLive = isLive,
                liveElapsedSeconds = liveElapsedSeconds,
                onToggleLive = {
                    if (isLive) {
                        isLive = false
                    } else {
                        liveStartedAt = System.currentTimeMillis()
                        liveElapsedSeconds = 0L
                        isLive = true
                    }
                }
            )
        }
        composable(Screen.Entertainment.route) {
            EntertainmentScreen(onNavigate = { navigate(it) })
        }
        composable(Screen.AudioDevices.route) {
            AudioDevicesScreen(onNavigate = { navigate(it) })
        }
        composable(Screen.LiveChat.route) {
            LiveChatScreen(onNavigate = { navigate(it) })
        }
        composable(Screen.Analytics.route) {
            AnalyticsScreen(onNavigate = { navigate(it) })
        }
        composable(Screen.Scenes.route) {
            ScenesScreen(onNavigate = { navigate(it) })
        }
        composable(Screen.RemoteControl.route) {
            RemoteControlScreen(onNavigate = { navigate(it) })
        }
        composable(Screen.Settings.route) {
            SettingsScreen(onNavigate = { navigate(it) })
        }
    }
}
