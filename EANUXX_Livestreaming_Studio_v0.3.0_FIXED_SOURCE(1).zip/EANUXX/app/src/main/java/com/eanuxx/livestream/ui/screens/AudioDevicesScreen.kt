package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.data.MockData
import com.eanuxx.livestream.ui.components.BottomNavBar
import com.eanuxx.livestream.ui.components.StatusDot
import com.eanuxx.livestream.ui.theme.*

@Composable
fun AudioDevicesScreen(onNavigate: (String) -> Unit) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Audio", "Devices", "Lights")

    // Local mutable levels
    val levels = remember {
        mutableStateMapOf<String, Float>().apply {
            MockData.audioSources.forEach { put(it.id, it.level) }
        }
    }
    val muted = remember { mutableStateMapOf<String, Boolean>() }
    var addSourceStatus by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onNavigate("studio") }) {
                Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
            }
            Text("Audio & Devices", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        TabRow(selectedTabIndex = selectedTab, containerColor = Background, contentColor = Primary) {
            tabs.forEachIndexed { i, t ->
                Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(t) })
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    MockData.audioSources.forEach { src ->
                        AudioFader(
                            name = src.name,
                            level = levels[src.id] ?: 0.5f,
                            muted = muted[src.id] == true,
                            onLevelChange = { levels[src.id] = it },
                            onToggleMute = { muted[src.id] = !(muted[src.id] == true) }
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { addSourceStatus = "Audio source picker is ready for device routing." },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(8.dp))
                        Text("+ Add Audio Source")
                    }
                }
                1, 2 -> {
                    Text(
                        if (selectedTab == 1) "Connected Devices" else "Lighting",
                        color = TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(12.dp))
                    MockData.devices.forEach { d ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Surface)
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                when (d.type) {
                                    "camera" -> Icons.Default.Videocam
                                    "mic" -> Icons.Default.Mic
                                    "speaker" -> Icons.Default.Speaker
                                    else -> Icons.Default.Lightbulb
                                },
                                null,
                                tint = Primary
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.name, color = TextPrimary, fontWeight = FontWeight.Medium)
                                Text(d.type.replaceFirstChar { it.uppercase() }, color = TextMuted, fontSize = 12.sp)
                            }
                            StatusDot(d.isConnected)
                            Spacer(Modifier.width(6.dp))
                            Text(if (d.isConnected) "Connected" else "Offline", color = if (d.isConnected) Success else TextMuted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }

        BottomNavBar(currentRoute = "studio", onNavigate = onNavigate)
    }
}

@Composable
private fun AudioFader(name: String, level: Float, muted: Boolean, onLevelChange: (Float) -> Unit, onToggleMute: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Surface)
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(name, color = TextPrimary, fontWeight = FontWeight.Medium)
            Text("${(level * 100).toInt()}%", color = TextSecondary, fontSize = 13.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeUp, null, tint = TextMuted, modifier = Modifier.size(18.dp))
            Slider(
                value = level,
                onValueChange = onLevelChange,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = Primary,
                    activeTrackColor = Primary,
                    inactiveTrackColor = CardBorder
                )
            )
            IconButton(onClick = onToggleMute) {
                Icon(if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, tint = if (muted) LiveRed else TextMuted, modifier = Modifier.size(20.dp))
            }
        }
    }
}
