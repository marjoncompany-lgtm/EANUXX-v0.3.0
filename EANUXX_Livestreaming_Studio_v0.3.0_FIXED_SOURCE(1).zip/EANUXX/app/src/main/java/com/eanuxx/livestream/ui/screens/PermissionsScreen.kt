package com.eanuxx.livestream.ui.screens

import android.Manifest
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.ui.components.PrimaryButton
import com.eanuxx.livestream.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PermissionsScreen(onContinue: () -> Unit) {
    val permissions = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
        }
    }

    val permissionState = rememberMultiplePermissionsState(permissions)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(40.dp))
        Text(
            "EANUXX",
            color = TextPrimary,
            fontSize = 36.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Permission Setup",
            color = TextSecondary,
            fontSize = 18.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "We only request what is needed for live production.",
            color = TextMuted,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(32.dp))

        PermissionItem(Icons.Default.Videocam, "Camera", "Required for live video and preview")
        PermissionItem(Icons.Default.Mic, "Microphone", "Required for live audio and monitoring")
        PermissionItem(Icons.Default.Notifications, "Notifications", "Stream health and connection alerts")
        PermissionItem(Icons.Default.Bluetooth, "Bluetooth / Nearby", "Audio devices, lights, and peripherals")
        PermissionItem(Icons.Default.ScreenShare, "Screen Capture", "Requested only when you enable screen share (system dialog)")

        Spacer(Modifier.height(32.dp))

        if (permissionState.allPermissionsGranted) {
            PrimaryButton("Continue to Sign In", onClick = onContinue)
        } else {
            PrimaryButton(
                text = "Allow Permissions",
                onClick = { permissionState.launchMultiplePermissionRequest() }
            )
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onContinue) {
                Text("Skip for now", color = TextMuted)
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "You can change these later in Settings → Permissions & Privacy.",
            color = TextMuted,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun PermissionItem(icon: ImageVector, title: String, description: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Surface)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Primary.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Primary)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text(description, color = TextSecondary, fontSize = 13.sp)
        }
    }
}
