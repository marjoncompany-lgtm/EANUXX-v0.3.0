# EANUXX update signing

This release is deliberately configured as an **in-place update** for the EANUXX APK previously signed with the certificate whose SHA-256 fingerprint is:

`95:3F:44:4B:65:59:4F:10:FC:C4:56:A7:F5:44:3F:DB:95:54:AF:46:F9:A5:FB:72:BF:24:92:91:C8:48:C7:E0`

## Required

Use the **same** `EANUXX_NEW_CERT.p12` keystore used for the working installed APK. Do not generate a new certificate for later updates.

Create these GitHub Actions repository secrets:

- `EANUXX_KEYSTORE_BASE64` — base64 contents of the existing `EANUXX_NEW_CERT.p12`
- `EANUXX_KEYSTORE_PASSWORD` — the password for that keystore

The workflow checks the certificate fingerprint and stops the build if the wrong certificate is supplied. This prevents accidentally producing an APK that would require uninstalling the installed version.

## Versioning

This update uses:

- applicationId: `com.wEANUXX_20148007`
- versionCode: `3`
- versionName: `0.3.0-functional-update`

For every future update, increase `versionCode` and keep the same signing keystore/certificate.
