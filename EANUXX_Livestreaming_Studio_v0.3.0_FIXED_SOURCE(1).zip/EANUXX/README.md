# EANUXX — Livestreaming Studio v0.2.0

**Created by Marjon Sealza**  
Free access • No subscription required

## What changed

This revision turns the original high-fidelity foundation into a more functional Android build:

- Real **CameraX camera preview** in Studio instead of a static placeholder.
- Live timer now starts at zero and counts accurately while the local live session is active.
- Start All / Stop All state is handled consistently.
- Entertainment Box now loads real HTTPS web content for YouTube and Browser tabs through Android WebView.
- Search/load URL control is functional.
- Send to Live / Add to Scene provide explicit source state feedback.
- Audio mixer faders are interactive and mute buttons toggle state.
- Live Chat accepts and displays locally sent messages.
- Analytics refresh control is functional.
- Scene selection remains interactive.
- Platform/Streaming settings now include Facebook Live Producer **Server URL + Stream Key** fields.
- Stream URL/key are encrypted with an **Android Keystore-backed AES-GCM key** before being stored locally.
- GitHub Actions workflow builds, zip-aligns and signs a release APK with V1 + V2 + V3 APK signatures.
- Package ID remains `com.wEANUXX_20148007` so the updated build targets the same application identity as the previously repaired APK.

## Important production boundary

The app UI and device-side functions above are real, but a professional multistreaming product still requires a verified media delivery engine and official platform integrations. This revision does **not** falsely claim that a button alone can publish to YouTube/Facebook/Instagram/TikTok/X.

For a real broadcast path, the next implementation must add:

1. Camera/screen/media composition.
2. Audio mixing.
3. H.264/AAC encoding.
4. RTMP/SRT/WebRTC transport as appropriate.
5. Destination-specific live ingestion.
6. Official platform authorization/APIs for metrics and chat.
7. Foreground service/reconnect/crash recovery.
8. Long-duration and poor-network testing.

The uploaded EANUXX plan explicitly requires a validated media engine and at least one complete end-to-end platform broadcast path before the app claims production streaming support.

## Build on GitHub

Push the `EANUXX/` project to GitHub. The included workflow `.github/workflows/build-apk.yml` runs on every push to `main` and can also be started manually from **Actions → Build EANUXX APK → Run workflow**.

The workflow builds a release APK, zip-aligns it and signs it with APK Signature Scheme V1 + V2 + V3. By default it uses an ephemeral certificate password for the build; for a persistent release certificate, add a GitHub Actions secret named `EANUXX_KEYSTORE_PASSWORD`.

## Design basis

The visual and feature direction follows the uploaded EANUXX application plan: Home, Studio, Entertainment Box, Audio & Devices, Live Chat, Analytics, Scenes, Remote Control, Settings, dark professional production UI, connected platform controls and secure credential handling.
