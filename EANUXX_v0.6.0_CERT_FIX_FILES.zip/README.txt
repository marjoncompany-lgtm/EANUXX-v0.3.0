EANUXX v0.6.0 certificate verification fix

Use only build-apk.yml from this package.
Replace the existing .github/workflows/build-apk.yml completely.

Do NOT upload this package ZIP to the repository.
Keep exactly one source ZIP at the repository root.
Keep the existing EANUXX_KEYSTORE_BASE64 and EANUXX_KEYSTORE_PASSWORD secrets unchanged.

The fix removes the heredoc/Python command substitution that caused:
syntax error near unexpected token '('

It extracts the apksigner SHA-256 digest with awk instead.
