## v0.4.0 Android 17 build hardening

- Migrated the Android module to AGP 9 built-in Kotlin; removed the incompatible `org.jetbrains.kotlin.android` plugin.
- Kept the Compose compiler plugin with a matching Kotlin toolchain.
- Enabled generated `BuildConfig` because the app records its installed version code.
- Uses Kotlin compiler JVM target 17 through the modern compiler options DSL.
- Hardened the CI build around Android API 37 and reproducible source selection.

# EANUXX v0.4.0 Professional Update

## Update-safe
- versionCode 5 / versionName 0.4.0-professional-update
- package and signing identity remain unchanged
- designed to update v0.3.1 without uninstalling

## Reliability
- removed first-launch dependence on the placeholder account screen
- permission gate only blocks when camera/microphone permissions are actually missing
- camera lens switching is supported
- camera binding is not repeated every second by the live timer

## Security
- Facebook stream key remains Android Keystore protected
- stream key is masked in the UI
- HTTPS-only server URL validation
- minimum stream-key length validation

## Settings
- persistent auto-reconnect preference
- persistent low-latency preference
- correct v0.4.0 version display

## Known limitation
The current source does not contain a complete hardware/software encoder and platform broadcast transport. Therefore the Start All control is still a production-control state/timer rather than proof of a live network broadcast. A real multistream engine must be added for true end-to-end broadcasting.


## v0.4.0 — Android compatibility hardening
- Raised compileSdk/targetSdk to Android 17 (API 37).
- Updated Android Gradle Plugin to 8.13.2 and Gradle build workflow to 8.13.
- Updated CameraX to 1.6.2, including Android 17+ camera compatibility fixes.
- Kept minSdk 26 so existing Android 8+ devices remain installable.
- Enabled Android 17 predictive-back compatibility via the supported platform callback model.
- Release workflow now verifies 16 KB APK page alignment.
- Kept the existing package ID and signing certificate requirements so normal updates do not require uninstalling the previous EANUXX release.


## Android 17 hardening

- Targets Android API 37 while retaining minSdk 26 for broad device compatibility.
- Uses Android Keystore AES-GCM for local stream credentials.
- WebView blocks cleartext/mixed content and local file/content access.
- Demo-only platform metrics and remote controls are no longer presented as real connections.
- Release artifacts are aligned for 16 KB page-size compatibility and signed with the existing EANUXX update certificate.
