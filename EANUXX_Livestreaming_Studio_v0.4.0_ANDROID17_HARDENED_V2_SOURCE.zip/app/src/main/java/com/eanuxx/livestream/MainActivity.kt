package com.eanuxx.livestream

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.eanuxx.livestream.data.AppPrefs
import com.eanuxx.livestream.ui.navigation.Screen
import com.eanuxx.livestream.ui.screens.*
import com.eanuxx.livestream.ui.theme.Background
import com.eanuxx.livestream.ui.theme.EanuxxTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EanuxxTheme {
                Surface(modifier = androidx.compose.ui.Modifier.fillMaxSize(), color = Background) {
                    EanuxxApp()
                }
            }
        }
    }
}

@Composable
fun EanuxxApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val navController = rememberNavController()
    val prefs = remember { AppPrefs(context) }
    val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    val micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val needsPermissions = !cameraGranted || !micGranted
    val startRoute = if (needsPermissions) Screen.Permissions.route else Screen.Home.route

    var isLive by remember { mutableStateOf(false) }
    var liveStartedAt by remember { mutableLongStateOf(0L) }
    var liveElapsedSeconds by remember { mutableLongStateOf(0L) }

    LaunchedEffect(isLive, liveStartedAt) {
        while (isLive) {
            liveElapsedSeconds = ((System.currentTimeMillis() - liveStartedAt) / 1000L).coerceAtLeast(0L)
            delay(1000L)
        }
    }

    LaunchedEffect(Unit) {
        prefs.lastSeenVersionCode = BuildConfig.VERSION_CODE
    }

    fun navigate(route: String) {
        navController.navigate(route) {
            launchSingleTop = true
            restoreState = true
        }
    }

    NavHost(navController = navController, startDestination = startRoute) {
        composable(Screen.Permissions.route) {
            PermissionsScreen(onContinue = {
                prefs.setupCompleted = true
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Permissions.route) { inclusive = true }
                }
            })
        }
        composable(Screen.Auth.route) {
            AuthScreen(onAuthenticated = {
                prefs.setupCompleted = true
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Auth.route) { inclusive = true }
                }
            })
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigate = { navigate(it) },
                onStartAll = {
                    if (!isLive) {
                        liveStartedAt = System.currentTimeMillis()
                        liveElapsedSeconds = 0L
                        isLive = true
                    }
                    navigate(Screen.Studio.route)
                }
            )
        }
        composable(Screen.Studio.route) {
            StudioScreen(
                onNavigate = { navigate(it) },
                isLive = isLive,
                liveElapsedSeconds = liveElapsedSeconds,
                onToggleLive = {
                    if (isLive) isLive = false
                    else {
                        liveStartedAt = System.currentTimeMillis()
                        liveElapsedSeconds = 0L
                        isLive = true
                    }
                }
            )
        }
        composable(Screen.Entertainment.route) { EntertainmentScreen(onNavigate = { navigate(it) }) }
        composable(Screen.AudioDevices.route) { AudioDevicesScreen(onNavigate = { navigate(it) }) }
        composable(Screen.LiveChat.route) { LiveChatScreen(onNavigate = { navigate(it) }) }
        composable(Screen.Analytics.route) { AnalyticsScreen(onNavigate = { navigate(it) }) }
        composable(Screen.Scenes.route) { ScenesScreen(onNavigate = { navigate(it) }) }
        composable(Screen.RemoteControl.route) { RemoteControlScreen(onNavigate = { navigate(it) }) }
        composable(Screen.Settings.route) { SettingsScreen(onNavigate = { navigate(it) }) }
    }
}
