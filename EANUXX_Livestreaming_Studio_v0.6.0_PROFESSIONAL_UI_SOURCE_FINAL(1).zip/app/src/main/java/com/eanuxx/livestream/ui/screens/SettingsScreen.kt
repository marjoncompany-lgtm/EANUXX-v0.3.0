package com.eanuxx.livestream.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eanuxx.livestream.data.AppPrefs
import com.eanuxx.livestream.data.PlatformHandoff
import com.eanuxx.livestream.data.SecureStore
import com.eanuxx.livestream.ui.components.BottomNavBar
import com.eanuxx.livestream.ui.theme.*

@Composable
fun SettingsScreen(
    onNavigate: (String) -> Unit,
    platformHandoffResult: PlatformHandoff.Result? = null,
    onPlatformHandoffConsumed: () -> Unit = {}
) {
    val context = LocalContext.current
    val secureStore = remember { SecureStore(context) }
    val appPrefs = remember { AppPrefs(context) }
    val platformSpecs = remember { PlatformHandoff.platforms }

    var dialogSection by remember { mutableStateOf<String?>(null) }
    var selectedPlatform by remember { mutableStateOf("fb") }
    val serverUrls = remember { mutableStateMapOf<String, String>().apply { platformSpecs.forEach { put(it.id, secureStore.get(it.serverKey)) } } }
    val streamKeys = remember { mutableStateMapOf<String, String>().apply { platformSpecs.forEach { put(it.id, secureStore.get(it.streamKey)) } } }
    var saveError by remember { mutableStateOf("") }
    var handoffMessage by remember { mutableStateOf("") }
    var showApproval by remember { mutableStateOf(false) }
    var showFallback by remember { mutableStateOf(false) }

    LaunchedEffect(platformHandoffResult) {
        val result = platformHandoffResult ?: return@LaunchedEffect
        val spec = PlatformHandoff.spec(result.platformId) ?: return@LaunchedEffect
        serverUrls[result.platformId] = result.serverUrl
        streamKeys[result.platformId] = result.streamKey
        secureStore.put(spec.serverKey, result.serverUrl)
        secureStore.put(spec.streamKey, result.streamKey)
        selectedPlatform = result.platformId
        handoffMessage = "${spec.name} settings received and saved securely."
        dialogSection = "Platforms"
        onPlatformHandoffConsumed()
    }

    val sections = listOf(
        "Camera" to Icons.Default.Videocam,
        "Audio" to Icons.Default.Mic,
        "Devices" to Icons.Default.Devices,
        "Streaming" to Icons.Default.Stream,
        "Platforms" to Icons.Default.Link,
        "Metadata & Hashtags" to Icons.Default.Tag,
        "Scenes" to Icons.Default.Layers,
        "Recording" to Icons.Default.FiberManualRecord,
        "Notifications" to Icons.Default.Notifications,
        "Account / Security" to Icons.Default.Security,
        "Permissions & Privacy" to Icons.Default.PrivacyTip,
        "Advanced" to Icons.Default.Tune
    )

    Column(Modifier.fillMaxSize().statusBarsPadding().background(Background)) {
        Text("Settings", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(20.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            sections.forEach { (title, icon) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface).clickable { dialogSection = title }
                        .padding(14.dp).padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, null, tint = Primary, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(title, color = TextPrimary, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("EANUXX  •  v0.6.0-professional-ui", color = TextMuted, fontSize = 12.sp)
            Text("Created by Marjon Sealza", color = TextMuted, fontSize = 12.sp)
            Text("Free access • No subscription required", color = Success, fontSize = 12.sp)
            Spacer(Modifier.height(24.dp))
        }
        BottomNavBar("settings", onNavigate)
    }

    if (dialogSection != null) {
        val title = dialogSection!!
        AlertDialog(
            onDismissRequest = { dialogSection = null },
            title = { Text(title) },
            text = {
                when (title) {
                    "Platforms", "Streaming" -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Connect all five platforms", fontWeight = FontWeight.Bold)
                        Text("Each platform has the same approval-first Auto-Fill control. EANUXX only accepts credentials returned by an authorized platform integration and keeps the stream key encrypted on this device.", color = TextSecondary, fontSize = 12.sp)

                        platformSpecs.forEach { spec ->
                            val connected = !serverUrls[spec.id].isNullOrBlank() && !streamKeys[spec.id].isNullOrBlank()
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Background).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(spec.name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        when {
                                            connected -> "Connected / credentials saved"
                                            spec.id == "yt" -> "OAuth + Live API ready after Google app configuration"
                                            spec.id == "fb" || spec.id == "ig" -> "Meta authorization required for automatic live setup"
                                            spec.id == "tt" -> "TikTok authorization/review required; manual fallback available"
                                            else -> "Official live-ingest API availability must be confirmed; manual fallback available"
                                        },
                                        color = if (connected) Success else TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                                TextButton(onClick = { selectedPlatform = spec.id; showApproval = true }) {
                                    Text("Connect / Auto-Fill", color = Primary)
                                }
                            }
                        }

                        val spec = PlatformHandoff.spec(selectedPlatform)!!
                        HorizontalDivider()
                        Text("${spec.name} Live settings", fontWeight = FontWeight.Bold)
                        if (handoffMessage.isNotBlank()) Text(handoffMessage, color = Success, fontSize = 12.sp)

                        OutlinedTextField(
                            value = serverUrls[selectedPlatform] ?: "",
                            onValueChange = { serverUrls[selectedPlatform] = it; saveError = "" },
                            label = { Text("Server URL") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = streamKeys[selectedPlatform] ?: "",
                            onValueChange = { streamKeys[selectedPlatform] = it; saveError = "" },
                            label = { Text("Stream Key") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                        )
                        Text("The stream key is encrypted with Android Keystore and remains on this device.", color = TextMuted, fontSize = 12.sp)
                        Text("Auto-Fill is approval-based. It never reads another app's private data. Where a platform requires a developer app, OAuth scope, API approval, or server-side token exchange, those requirements must be configured before automatic credentials can be returned.", color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp)
                        if (saveError.isNotEmpty()) Text(saveError, color = LiveRed, fontSize = 12.sp)
                    }
                    "Advanced" -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Auto reconnect", color = TextPrimary); Text("Retry after a temporary network drop.", color = TextMuted, fontSize = 12.sp) }
                            Switch(checked = appPrefs.autoReconnect, onCheckedChange = { appPrefs.autoReconnect = it })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Low latency mode", color = TextPrimary); Text("Prefer faster live response when supported.", color = TextMuted, fontSize = 12.sp) }
                            Switch(checked = appPrefs.lowLatency, onCheckedChange = { appPrefs.lowLatency = it })
                        }
                    }
                    else -> Text("Device-specific controls appear when supported by Android. EANUXX keeps unsupported controls disabled rather than pretending they are active.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title == "Platforms" || title == "Streaming") {
                        val spec = PlatformHandoff.spec(selectedPlatform)!!
                        val url = (serverUrls[selectedPlatform] ?: "").trim()
                        val key = (streamKeys[selectedPlatform] ?: "").trim()
                        if (url.isNotEmpty() && !url.startsWith("https://", true)) { saveError = "Server URL must use HTTPS."; return@TextButton }
                        if (key.isNotEmpty() && key.length < 8) { saveError = "Stream key looks too short."; return@TextButton }
                        secureStore.put(spec.serverKey, url)
                        secureStore.put(spec.streamKey, key)
                    }
                    saveError = ""; dialogSection = null
                }) { Text("Save", color = Primary) }
            },
            dismissButton = { TextButton(onClick = { dialogSection = null }) { Text("Close") } },
            containerColor = Surface, titleContentColor = TextPrimary, textContentColor = TextSecondary
        )
    }

    if (showApproval) {
        val spec = PlatformHandoff.spec(selectedPlatform)!!
        AlertDialog(
            onDismissRequest = { showApproval = false },
            title = { Text("Connect ${spec.name}?") },
            text = { Text("EANUXX will start the authorized connection flow for ${spec.name}. Continue only if you approve it. Automatic filling happens only if the platform's official integration returns the Server URL and Stream Key; otherwise you can enter them manually.") },
            confirmButton = {
                TextButton(onClick = {
                    showApproval = false
                    if (!PlatformHandoff.launch(context, selectedPlatform)) showFallback = true
                }) { Text("Continue", color = Primary) }
            },
            dismissButton = { TextButton(onClick = { showApproval = false }) { Text("Cancel") } },
            containerColor = Surface, titleContentColor = TextPrimary, textContentColor = TextSecondary
        )
    }

    if (showFallback) {
        val spec = PlatformHandoff.spec(selectedPlatform)!!
        AlertDialog(
            onDismissRequest = { showFallback = false },
            title = { Text("Open ${spec.name} in browser?") },
            text = { Text("The ${spec.name} app was not available. Open the official web live/creator page instead. Manual Server URL and Stream Key entry remains available if the platform does not provide an automatic callback.") },
            confirmButton = {
                TextButton(onClick = {
                    showFallback = false
                    val url = Uri.parse(spec.launchUrl)
                    context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, url).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Open Browser", color = Primary) }
            },
            dismissButton = { TextButton(onClick = { showFallback = false }) { Text("Cancel") } },
            containerColor = Surface, titleContentColor = TextPrimary, textContentColor = TextSecondary
        )
    }
}
